import Phaser, { Game } from "phaser";
import CONSTANTS from "../utils/constants";
import rectangle from "phaser";

var cursors;
var divisor;
var player;
var cursors;
export default class GameScene extends Phaser.Scene {
  cursors;
  player;
  divisor;
  constructor() {
    super({ key: CONSTANTS.SCENES.GAME });
  }

  

    
  preload() {

    

    
  }

  create() {
    
    this.add.image(0, 0, "GAMEBACKGROUND")
    .setDisplaySize(this.game.renderer.width, this.game.renderer.height)
    .setInteractive({ useHandCursor: false })
    .setOrigin(0)
    .setDepth(0)

    

    

  

    //divisor = this.add.rectangle(387, 10, 35, 750, 0);
    this.divisor = this.physics.add.staticGroup();
    
    this.divisor.create(387,187, 'DIVISOR')
      //.setDisplaySize(40, this.game.renderer.height)
    //this.divisor.create(150,150, )
    
    this.player = this.physics.add.sprite(20,10, 'principal');
    this.player.setCollideWorldBounds(true);
    
    this.physics.add.collider(this.player, this.divisor,)
    
    this.anims.create({
      key: 'left',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 3  }),
      frameRate: 10,
      repeat: -1
    });

    this.anims.create({
      key: 'turn',
      frames: [ { key: 'principal', frame: 4 } ],
      frameRate: 20
    });

    this.anims.create({
      key: 'right',
      frames: this.anims.generateFrameNumbers('principal', { start: 5, end: 8 }),
      frameRate: 10,
      repeat: -1
    });

    this.anims.create({
      key: 'down',
      frames: this.anims.generateFrameNumbers('principal', { start: 5, end: 8 }),
      frameRate: 10,
      repeat: -1
    });

    this.anims.create({
      key: 'up',
      frames: this.anims.generateFrameNumbers('principal', { start: 5, end: 8 }),
      frameRate: 10,
      repeat: -1
    });


    this.cursors = this.input.keyboard.createCursorKeys();

    
  }

  update() {

  
    if (this.cursors.left.isDown)
    {
        this.player.setVelocityX(-160);

        this.player.anims.play('left', true);
    }
    else if (this.cursors.right.isDown)
    {
        this.player.setVelocityX(160);

        this.player.anims.play('right', true);
    }
    else if (this.cursors.down.isDown)
    {
        this.player.setVelocityY(160);

        this.player.anims.play('down', true);
    }
    else if (this.cursors.up.isDown)
    {
        this.player.setVelocityY(-160);

        this.player.anims.play('up', true);
    }
    else
    {
        this.player.setVelocityX(0);
        this.player.setVelocityY(0);

        this.player.anims.play('turn');
    }


    /*
    if (this.cursors.up.isDown && player.body.touching.down)
    {
        this.player.setVelocityY(-330);
    }
    */

  }

}