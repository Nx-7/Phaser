import Phaser from 'phaser';
import Scenes from "./scenes"

const config = {
    type: Phaser.AUTO,
    width: 666,
    height: 375,
    scene: [Scenes.Load, Scenes.Menu, Scenes.Game],
    physics: {
        default: 'arcade'
        
    }
};
var divisor;

window.game = new Phaser.Game(config);
