import Phaser, { Game } from "phaser";
import CONSTANTS from "../utils/constants";
import rectangle from "phaser";



export default class GameScene extends Phaser.Scene {
  cursors;
  player;
  divisor;
  enemy;
  pizza;
  alvos;
  constructor() {
    super({ key: CONSTANTS.SCENES.GAME });
  }

  

    
  preload() {
    
    
  }

  create() {
    
    
    this.add.image(0, 0, "GAMEBACKGROUND")
    .setDisplaySize(this.game.renderer.width, this.game.renderer.height)
    .setInteractive({ useHandCursor: false })
    .setOrigin(0)
    .setDepth(0)

  

    //-----------Divisor---------------
    this.divisor = this.physics.add.staticGroup();
    this.divisor = this.physics.add.staticImage(387, 187, 'DIVISOR')
    this.divisor.setSize(40 , 375)
    this.divisor.setDisplaySize(40 , 375);
    
    

    
    //--------------Player----------------

    this.player = this.physics.add.sprite(200,190, 'principal');
    this.player.setCollideWorldBounds(true);
    this.player.setDisplaySize(78, 52)
    
    
    this.physics.add.collider(this.player, this.divisor,)
    
    this.anims.create({
      key: 'left',
      frames: this.anims.generateFrameNumbers('principal', { start: 3, end: 5  }),
      frameRate: 12,
      repeat: 0
    });

    

    this.anims.create({
      key: 'right',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 2 }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'down',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 2 }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'up',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 2 }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'alvo-stand',
      frames: this.anims.generateFrameNumbers('alvo', { start: 0, end: 1 }),
      frameRate: 3,
      repeat: -1
    })

    this.anims.create({
      key: 'alvo-hit',
      frames: this.anims.generateFrameNumbers('alvo', { start: 2, end: 3 }),
      frameRate: 15,
      repeat: 0
    })

    this.cursors = this.input.keyboard.createCursorKeys();



    //-----------ALVO-----------

    this.alvos = this.physics.add.group();
    this.adicionarAlvo()
    this.adicionarAlvo()
    this.adicionarAlvo()
    this.adicionarAlvo()

    
    



    

    //------------Pizza-------------
    
    this.pizzas = this.physics.add.group()
    this.input.on('pointerdown', () => {
      this.throwPizza(this.player.x, this.player.y)

    })

    this.physics.add.collider(this.pizzas, this.alvos, (pizza, alvo) => {
      alvo.onHit()
      pizza.destroy()
    })

    

  }


  update() {

  
    if (this.cursors.left.isDown)
    {
        this.player.setVelocityX(-160);

        this.player.anims.play('left', true);
    }
    else if (this.cursors.right.isDown)
    {
        this.player.setVelocityX(160);

        this.player.anims.play('right', true);
    }
    else if (this.cursors.down.isDown)
    {
        this.player.setVelocityY(160);

        this.player.anims.play('down', true);
    }
    else if (this.cursors.up.isDown)
    {
        this.player.setVelocityY(-160);

        this.player.anims.play('up', true);
    }
    else
    {
        this.player.setVelocityX(0);
        this.player.setVelocityY(0);

       
    }
    

  }

  throwPizza() {
    const pizza = this.physics.add.image(this.player.x, this.player.y, 'PIZZA')
    this.pizzas.add(pizza)
    this.pizzas.setVelocityX(350)
  }

  
  posicaoAlvos(){
    let coordinates = [];
    
    for (let i = 0; i < 5; i++) {
      let xy = Math.floor(Math.random() * (620 - 450 + 1)) + 450;
      let yy = Math.floor(Math.random() * (331 - 42 + 1)) + 42;
      coordinates.push([xy, yy]);
    }
    
    /*
    let coordinates = [];
    
    for (let i = 0; i < 20; i++) {
      let x = 450 + (i * 42);
      let y = 42 + (Math.floor(Math.random() * 6) * 52);
      coordinates.push([x, y]);
    } */
  }
  
  
  adicionarAlvo(){
    const x = Phaser.Math.Between(450, 620)
    const y = Phaser.Math.Between(42, 331)
    new Alvo(this, this.alvos, x, y)
    
  }
  
}

class Alvo extends Phaser.GameObjects.Sprite {
  scene = null
  group = null

  constructor(scene, group, x, y) {
    super(scene, x, y, 'alvo')

    this.scene = scene
    this.group = group

    scene.physics.add.existing(this)
    scene.add.existing(this)
    group.add(this)

    this.body.setImmovable(true)
    this.setDisplaySize(42, 52)

    this.play('alvo-stand')
  }


  onHit() {
    this.play('alvo-hit')
    this.playAfterRepeat('alvo-stand')
    
  }

  
}



