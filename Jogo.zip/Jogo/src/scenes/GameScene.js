import Phaser, { Game } from "phaser";
import CONSTANTS from "../utils/constants";
import rectangle from "phaser";

var scoreText
var gameOver = false
var score = 0
var lastScore = 0
var godMode = false;
var liveText 
var keyG

export default class GameScene extends Phaser.Scene {
  cursors;
  player;
  divisor;
  enemy;
  pizza;
  alvos;
  godMode = false;
  keyG;
  gameOver = false;
  scoreText = null;
  speed = 0.005;
  constructor() {
    super({ key: CONSTANTS.SCENES.GAME });
  }

  
  preload() {
    
    
  }

  create() {
    this.song = this.sound.add('musicAudio', {volume: 0.2})

    this.song.play()
    
    
    this.add.image(0, 0, "GAMEBACKGROUND")
    .setDisplaySize(this.game.renderer.width, this.game.renderer.height)
    .setInteractive({ useHandCursor: false })
    .setOrigin(0)
    .setDepth(0)

    scoreText = this.add.text(16, 16, 'score: 0', { fontSize: '32px', fill: '#fff' });
    liveText = this.add.text(16, 335, 'lives: 3', { fontSize: '24px', fill: '#fff' })

    //-----------Divisor---------------
    this.divisor = this.physics.add.staticGroup();
    this.divisor = this.physics.add.staticImage(387, 187, 'DIVISOR')
    this.divisor.setSize(40 , 375)
    this.divisor.setDisplaySize(40 , 375);
    
    

    
    //--------------Player----------------

    this.player = this.physics.add.sprite(200,190, 'principal');
    this.player.setCollideWorldBounds(true);
    this.player.setDisplaySize(78, 52)

    keyG = this.input.keyboard. addKey (Phaser. Input. Keyboard. KeyCodes.G) ; 
    
    
    
    this.physics.add.collider(this.player, this.divisor,)

    this.anims.create({
      key: 'inimigo',
      frames: this.anims.generateFrameNumbers('inimigo', { start: 0, end: 1 }),
      frameRate: 3,
      repeat: -1
    })
    
    this.anims.create({
      key: 'left',
      frames: this.anims.generateFrameNumbers('principal', { start: 3, end: 5  }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'right',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 2 }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'down',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 2 }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'up',
      frames: this.anims.generateFrameNumbers('principal', { start: 0, end: 2 }),
      frameRate: 12,
      repeat: 0
    });

    this.anims.create({
      key: 'alvo-stand',
      frames: this.anims.generateFrameNumbers('alvo', { start: 0, end: 1 }),
      frameRate: 3,
      repeat: -1
    })

    this.anims.create({
      key: 'alvo-hit',
      frames: this.anims.generateFrameNumbers('alvo', { start: 2, end: 3 }),
      frameRate: 15,
      repeat: 0
    })

    this.cursors = this.input.keyboard.createCursorKeys();



    //-----------ALVO-----------

    this.alvos = this.physics.add.group();
    this.adicionarAlvo()
    this.adicionarAlvo()
    this.adicionarAlvo()
    this.adicionarAlvo()
    this.adicionarAlvo()
   

    

    
    //-----------INIMIGO-------------
    
    this.enemy = this.physics.add.sprite(420,190, 'inimigo');
    this.enemy.setCollideWorldBounds(true);
    this.enemy.setDisplaySize(42, 52)
    .play('inimigo')


    //------------Pizza-------------
    
    this.pizzas = this.physics.add.group()
    this.input.on('pointerdown', () => {
      this.throwPizza(this.player.x, this.player.y)

    })

    lastScore = 0

    //----------Colliders-----------

    var lives = 3
    this.physics.add.collider(this.pizzas, this.alvos, (pizza, alvo) => {
      alvo.onHit()

      score += 100;
      scoreText.setText('Score: ' + score);

      if (score > lastScore + 900) {
        this.speed += 0.005;
        lives += 1
        liveText.setText('lives: ' + lives)
        lastScore = score;
      }

      pizza.destroy()
      
    })

    
    godMode = false
    this.physics.add.collider(this.pizzas, this.enemy, (pizza, enemy) => {
      pizza.body.velocity.x = 0;
      enemy.destroy();
      
      
      if (godMode == false){
        lives -= 1;
        liveText.setText('lives: ' + lives)

        if (lives === 0){
          this.player.setTint(0xff0000);
          gameOver = true;
          this.add.text(80, 150 , "Game Over", { fontSize: '100px', fill: 'red' })
          this.input.on("pointerdown", ()=> {this.scene.start(CONSTANTS.SCENES.MENU)})
          
        } else {

        }
      }

    });
  
  }


  update() {

    if (gameOver)
    {
      
      return;
    }

    this.enemy.y = Phaser.Math.Linear(this.enemy.y, this.player.y, this.speed);

  
    if (this.cursors.left.isDown)
    {
        this.player.setVelocityX(-160);

        this.player.anims.play('left', true);
    }
    else if (this.cursors.right.isDown)
    {
        this.player.setVelocityX(160);

        this.player.anims.play('right', true);
    }
    else if (this.cursors.down.isDown)
    {
        this.player.setVelocityY(160);

        this.player.anims.play('down', true);
    }
    else if (this.cursors.up.isDown)
    {
        this.player.setVelocityY(-160);

        this.player.anims.play('up', true);
    }
    else
    {
        this.player.setVelocityX(0);
        this.player.setVelocityY(0);
    }

    if (Phaser.Input.Keyboard.JustDown(keyG)) 
    {
      godMode = !godMode
       
    }

  }

  throwPizza() {
    const pizza = this.physics.add.image(this.player.x, this.player.y, 'PIZZA')
    this.pizzas.add(pizza)
    this.pizzas.setVelocityX(350)
  }

  collectPizza (principal , pizza)
  {
    pizza.disableBody(true, true);
  }
  
  adicionarAlvo(){
    const x = Phaser.Math.Between(450, 620)
    const y = Phaser.Math.Between(42, 331)
    new Alvo(this, this.alvos, x, y)
    
  }
}


class Alvo extends Phaser.GameObjects.Sprite {
  scene = null
  group = null

  constructor(scene, group, x, y) {
    super(scene, x, y, 'alvo')

    this.scene = scene
    this.group = group

    scene.physics.add.existing(this)
    scene.add.existing(this)
    group.add(this)

    this.body.setImmovable(true)
    this.setDisplaySize(42, 52)

    this.play('alvo-stand')
  }


  onHit() {
    this.play('alvo-hit')
    this.playAfterRepeat('alvo-stand')
    
  }

  
}


