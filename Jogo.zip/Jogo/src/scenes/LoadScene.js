import Phaser from "phaser";
import CONSTANTS from "../utils/constants";

export default class LoadScene extends Phaser.Scene {
  constructor() {
    super({ key: CONSTANTS.SCENES.LOAD });
  }

  preload() {
    console.log("Preloading loading scene..");
    
    this.loadImages()
    this.loadSpritesheets()
    
  }

  create() {
    this.scene.start(CONSTANTS.SCENES.MENU)
  }

  loadImages() {
    for (let item in CONSTANTS.IMAGE) {
      this.load.image(item, `./src/assets/${CONSTANTS.IMAGE[item]}`)
      
    }
  }

  loadSpritesheets(){
    for (let item in CONSTANTS.SPRITESHEETS) {
      this.load.spritesheet('principal', `./src/assets/s_bear.png`, { frameWidth: 39, frameHeight: 26 })
      this.load.spritesheet('alvo', `./src/assets/s_kiddo.png`, { frameWidth: 21, frameHeight: 26 })
      this.load.spritesheet('inimigo', './src/assets/s_grey_bear.png', {frameWidth: 21, frameHeight: 26})

    }
  }
}
