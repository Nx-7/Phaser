import Phaser from "phaser";
import CONSTANTS from "../utils/constants";
import GameScene from "./GameScene";

export default class MenuScene extends Phaser.Scene{
  constructor() {
    super({ key: CONSTANTS.SCENES.MENU });
  }

  preload() {
    console.log("Preloading menu scene..");
  }

  create() {

    // Background Menu
    this.add.image(0, 0, "MENUBACKGROUND")
      .setDisplaySize(this.game.renderer.width, this.game.renderer.height)
      .setInteractive({ useHandCursor: false })
      .setOrigin(0)
      .setDepth(0)

    // Titulo
    this.add.text(this.game.renderer.width / 2, this.game.renderer.height * 0.10, "Pizzeria Simulator")
      .setOrigin(0.5)
      .setStyle({
        fill: "#fff",
        fontSize: 48,
        fontStyle: "bold",
        align: "center",
       
      })
      this.add.text(this.game.renderer.width * 0.5, this.game.renderer.height * 0.9, 'Press to Start...').setOrigin(0.5)
      this.input.on("pointerdown", ()=> {this.scene.start(CONSTANTS.SCENES.GAME)})

    
    //------ Criar as Animaçoes dos sprites que estao na MenuScene --------
    this.anims.create({
      key: 'alvo-stand',
      frames: this.anims.generateFrameNumbers('alvo', { start: 0, end: 1 }),
      frameRate: 4,
      repeat: -1
    })

    this.anims.create({
      key: 'principal-stand',
      frames: this.anims.generateFrameNumbers('principal1', { start: 0, end: 2 }),
      frameRate: 4,
      repeat: -1
    })

    
    
    //------Sprites Animados no MenuScene -------
    this.add.sprite(510, 220, 'alvo')
      .setDisplaySize(63, 78)
      .play('alvo-stand')

    this.add.sprite(430, 200, 'alvo')
      .setDisplaySize(63, 78)
      .play('alvo-stand')
    
    this.add.sprite(460, 280, 'alvo')
      .setDisplaySize(63, 78)
      .play('alvo-stand')

    this.add.sprite(190, 220, 'principal1')
      .setDisplaySize(101, 68)
      .play('principal-stand')

    this.add.image(237, 198, 'PIZZA')
      .setScale(2)
    

  }

  

  update() { 
    
  }
}



