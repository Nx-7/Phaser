const CONSTANTS = {
    SCENES: {
        LOAD: "LOAD",
        MENU: "MENU",
        GAME: "GAME",
    },
    IMAGE: {
        BACKGROUND: "background.png",
        GAMEBACKGROUND: "mapafinal.png",
        ENEMY: "enemy.png",
        PIZZA: "pizza.png",
        TESTE: "teste.png",
        
        BACKGROUND2: "mapa2.png",
        DIVISOR: "divisor.png"
    },
    SPRITESHEETS: {
        PLAYER: "urso.png",
        ALVO: "alvo.png",

    }
};

export default CONSTANTS