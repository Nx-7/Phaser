const CONSTANTS = {
    SCENES: {
        LOAD: "LOAD",
        MENU: "MENU",
        GAME: "GAME",
    },
    IMAGE: {
        BACKGROUND: "background.png",
        GAMEBACKGROUND: "mapafinal.png",

        PIZZA: "pizza.png",
        TESTE: "teste.png",
        
        BACKGROUND2: "mapa2.png",
        DIVISOR: "divisor.png"
    },
    SPRITESHEETS: {
        PLAYER: "s_bear.png",
        ALVO: "s_kiddo.png",
        ENEMY: "s_grey_bear.png",
    }
};

export default CONSTANTS