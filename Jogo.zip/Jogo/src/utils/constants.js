const CONSTANTS = {
    SCENES: {
        LOAD: "LOAD",
        MENU: "MENU",
        GAME: "GAME",
    },
    IMAGE: {
        MENUBACKGROUND: "background.png",
        GAMEBACKGROUND: "mapafinal.png",
        PIZZA: "pizza.png",
        DIVISOR: "divisor.png"
    },
    SPRITESHEETS: {
        PLAYER: "urso.png",
        ALVO: "alvo.png",
        ENEMY: "enemy.png",

    }
    
};

export default CONSTANTS